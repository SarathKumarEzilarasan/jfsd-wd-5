package com.example.spring_webflux_demo.service.impl;

import com.example.spring_webflux_demo.dto.EmployeeDto;
import com.example.spring_webflux_demo.entity.Employee;
import com.example.spring_webflux_demo.repository.EmployeeRepository;
import com.example.spring_webflux_demo.service.EmployeeService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    private ModelMapper modelMapper;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository, ModelMapper modelMapper) {
        this.employeeRepository = employeeRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public Mono<EmployeeDto> saveEmployee(EmployeeDto employeeDto) {
        Employee employee = modelMapper.map(employeeDto, Employee.class);
        Mono<Employee> employeeMono = employeeRepository.save(employee);
        return employeeMono.map(e -> modelMapper.map(e, EmployeeDto.class));
    }

    @Override
    public Mono<EmployeeDto> getEmployee(String employeeId) {
        return null;
    }

    @Override
    public Flux<EmployeeDto> getAllEmployees() {
        return employeeRepository.findAll().map(employee -> modelMapper.map(employee, EmployeeDto.class));
    }

    @Override
    public Mono<EmployeeDto> updateEmployee(EmployeeDto employeeDto, String employeeId) {
        return null;
    }

    @Override
    public Mono<Void> deleteEmployee(String employeeId) {
        return null;
    }
}
