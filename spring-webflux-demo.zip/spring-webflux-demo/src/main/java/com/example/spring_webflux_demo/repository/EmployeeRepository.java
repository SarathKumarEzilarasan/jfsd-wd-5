package com.example.spring_webflux_demo.repository;

import com.example.spring_webflux_demo.entity.Employee;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface EmployeeRepository extends ReactiveCrudRepository<Employee,String> {
}
