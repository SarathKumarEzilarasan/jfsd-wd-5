package com.example.spring_webflux_demo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public class FluxMonoGeneratorService {
    public static Mono<String> nameMono() {
        return Mono.just("peter");
    }

    public static Flux<String> namesFlux() {
        return Flux.fromIterable(List.of("john", "zack"));
    }

    public static void main(String[] args) {
        namesFlux().log().subscribe(name -> System.out.println(name));
    }
}
