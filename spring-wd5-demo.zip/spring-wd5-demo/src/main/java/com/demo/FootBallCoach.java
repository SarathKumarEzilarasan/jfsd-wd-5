package com.demo;

public class FootBallCoach implements Coach{
    private WishService wishService;
    private String email;

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public String getDailyWorkOut(){
        return "Spend 30 mins kicking practice";
    }

    @Override
    public String getDailyWish() {
        return wishService.getDailyWish();
    }

    public void setWishService(WishService wishService) {
        this.wishService = wishService;
    }

    public void startupMethod(){
        System.out.println("started");
    }

    public void destroyMethod(){
        System.out.println("destroyed");
    }
}
