package com.demo;

public interface WishService {
    String getDailyWish();
}
