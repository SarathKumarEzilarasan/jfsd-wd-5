package com.demo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.List;

public class MyApp {
    public static void main(String[] args) {
//        CricketCoach coach = new CricketCoach();
//        FootBallCoach coach = new FootBallCoach();
//        Coach coach = new FootBallCoach();
//        Coach coach = new CricketCoach(new HappyWishService());
//        FootBallCoach coach = new FootBallCoach();
//        coach.setWishService(new HappyWishService());

        ClassPathXmlApplicationContext context =
                new ClassPathXmlApplicationContext("config.xml");

        Coach coach = context.getBean("myFootBallCoach", Coach.class);
//        FootBallCoach coach = context.getBean("myFootBallCoach", FootBallCoach.class);
//         System.out.println(coach.getEmail());
//        System.out.println(coach.getDailyWorkOut());
//        System.out.println(coach.getDailyWish());

        Coach coach1 = context.getBean("myFootBallCoach", Coach.class);

        System.out.println(coach1);
        System.out.println(coach);

        context.close();
    }
}
