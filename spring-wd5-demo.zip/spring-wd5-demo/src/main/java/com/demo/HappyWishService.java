package com.demo;

public class HappyWishService implements WishService {
    @Override
    public String getDailyWish() {
        return "Good luck for the match";
    }
}
