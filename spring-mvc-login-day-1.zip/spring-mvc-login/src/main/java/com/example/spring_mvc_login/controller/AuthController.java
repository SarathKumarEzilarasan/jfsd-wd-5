package com.example.spring_mvc_login.controller;

import com.example.spring_mvc_login.dto.UserDto;
import com.example.spring_mvc_login.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class AuthController {
    private UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/index")
    public String home(){
        return "index";
    }

    @GetMapping("/login")
    public String login(){
        return "login";
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model){
        UserDto userDto = new UserDto();
        model.addAttribute("user",userDto);
        return "register";
    }

//    @PostMapping("/register/save")
//    public String registration(@ModelAttribute("user") UserDto userDto){
//
//    }

    @GetMapping("/users")
    public String users(Model model){
       List<UserDto> userDtos = userService.findAllUsers();
       model.addAttribute("users",userDtos);
       return "users";
    }
}
