package test;

public interface Car {

    void tyres();

    void breaks();
}
