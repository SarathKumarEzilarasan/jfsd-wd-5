package test;

public class KiaSedan extends Kia {
    @Override
    public void tyres() {

    }

    public void breaks() {

    }
}
