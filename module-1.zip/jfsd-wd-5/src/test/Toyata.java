package test;

public class Toyata implements Car {

    public void tyres() {
        System.out.println("Apollo");
    }

    public void breaks() {
        System.out.println("breaks");
    }
}
