package test;

public class KiaSuv extends Kia{
    public void tyres() {

    }

    public void breaks(){

    }
}
