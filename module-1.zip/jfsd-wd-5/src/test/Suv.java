package test;

public class Suv extends Tata  {
}
