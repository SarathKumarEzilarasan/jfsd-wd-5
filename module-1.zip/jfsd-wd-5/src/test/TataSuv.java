package test;

public class TataSuv extends Tata {
}
