package test;

import java.util.List;

public class Gen {

    public <T> void equals(T a, T b) {
        a.equals(b);
    }

    public <T> void equals(List<?> arrayList, T b) {

    }
}

