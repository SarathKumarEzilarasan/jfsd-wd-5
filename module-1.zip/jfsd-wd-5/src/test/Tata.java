package test;

public class Tata implements Car {
    public void tyres() {
        System.out.println("JK tyres");
    }

    public void breaks() {

    }
}
