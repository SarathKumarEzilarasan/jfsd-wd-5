package test;

public abstract class Kia implements Car {

}
