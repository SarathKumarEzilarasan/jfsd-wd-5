package collections;

public record _Employee(String name, int age, int salary) {
    public static void print() {
        System.out.println("from print");
    }
}
