package demo;

public class Demo {

    static int x = 10000; // global or class variable
    int y = 20000;

    static {
        System.out.println("from static block");
    }

    // main method or main function
    public static void main(String[] args) {

        System.out.println("from main");
    }

    // custom method or user defined method
    public int add(int a, int b) { // function arguments or function parameters

        System.out.println(x);
        System.out.println(y);

        int x = a;
        int y = b;
        return x + y;
    }

    public static int sub(int a, int b) { // function arguments or function parameters
        int x = a;
        int y = b;
        return x - y;
    }
}

//  main -> add