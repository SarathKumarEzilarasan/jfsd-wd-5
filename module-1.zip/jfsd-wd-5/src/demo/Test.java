package demo;

import java.util.Comparator;

public class Test {

    public static void main(String[] args) {
        // comparable , comparator
        User user1 = new User("john", "user@123", "admin", 90, 7);
        User user2 = new User("peter", "peter@123", "admin", 80, 8);

        MarksComparator marksComparator = new MarksComparator();
        System.out.println(marksComparator.compare(user1, user2));

        GpaComparator gpaComparator = new GpaComparator();
        System.out.println(gpaComparator.compare(user1, user2));

    }
}

class MarksComparator implements Comparator<User> {
    @Override
    public int compare(User o1, User o2) {
        return o1.getMarks() - o2.getMarks();
    }
}

class GpaComparator implements Comparator<User> {
    @Override
    public int compare(User o1, User o2) {
        return o1.getGpa() - o2.getGpa();
    }
}
