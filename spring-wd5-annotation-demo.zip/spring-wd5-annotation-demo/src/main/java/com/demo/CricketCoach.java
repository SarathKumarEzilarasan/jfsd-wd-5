package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("myCricketCoach")
@Scope("prototype")
public class CricketCoach implements Coach{
//    @Autowired
//    private WishService wishService;
    private WishService wishService;

    public CricketCoach(@Qualifier("happyWishService") WishService wishService) {
        this.wishService = wishService;
    }

    public String getDailyWorkOut(){
        return "Spend 30 mins batting practice";
    }

    @Override
    public String getDailyWish() {
        return wishService.getDailyWish();
    }
}
