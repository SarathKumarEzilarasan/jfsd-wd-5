package com.demo;

import org.springframework.stereotype.Component;

@Component
public class HappyWishService implements WishService {
    @Override
    public String getDailyWish() {
        return "Good luck for the match";
    }
}
