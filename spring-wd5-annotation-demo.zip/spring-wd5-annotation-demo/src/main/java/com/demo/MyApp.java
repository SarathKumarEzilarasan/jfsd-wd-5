package com.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MyApp {
    public static void main(String[] args) {

        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(SportsConfig.class);

        Coach coach = context.getBean("myCricketCoach", Coach.class);

        System.out.println(coach.getDailyWorkOut());
        System.out.println(coach.getDailyWish());

        System.out.println(coach);

        context.close();
    }
}
