package com.demo;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class FootBallCoach implements Coach{
    private WishService wishService;
    @Value("${email}")
    private String email;

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public String getDailyWorkOut(){
        return "Spend 30 mins kicking practice";
    }

    @Override
    public String getDailyWish() {
        return wishService.getDailyWish();
    }

    @Autowired
    @Qualifier("motivateWishService")
    public void setWishService(WishService wishService) {
        this.wishService = wishService;
    }

    @PostConstruct
    public void startupMethod(){
        System.out.println("started");
    }

    @PreDestroy
    public void destroyMethod(){
        System.out.println("destroyed");
    }
}
