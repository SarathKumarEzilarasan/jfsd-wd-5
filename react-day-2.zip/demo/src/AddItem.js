import React from "react";
import { FaPlus } from "react-icons/fa";
import { useRef } from "react";


const AddItem = ({ newItem, setNewItem, handleSubmit }) => {
    const inputRef = useRef();
    return (
        <form className='addForm' onSubmit={handleSubmit}>
            <label htmlFor='addForm'>Add Item</label>
            <input autoFocus type="text" id="addForm" placeholder='Add Item' required value={newItem}
             onChange={(e)=>setNewItem(e.target.value)} ref={inputRef}  ></input>
            <button type='submit' onClick={()=> inputRef.current.focus()}>Submit</button>
        </form>
      )
};

export default AddItem;