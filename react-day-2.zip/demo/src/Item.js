import React from "react";
import { FaTrash } from "react-icons/fa";

const Item = ({ item, handleCheck, deleteTask }) => {
  return (
    <li className="item">
      <input
        type="checkbox"
        onChange={() => handleCheck(item.id)}
        checked={item.checked}
      ></input>
      <label
        onDoubleClick={() => handleCheck(item.id)}
        style={item.checked ? { textDecoration: "line-through" } : null}
      >
        {item.description}
      </label>
      <FaTrash role="button" onClick={() => deleteTask(item.id)} />
    </li>
  );
};

export default Item;