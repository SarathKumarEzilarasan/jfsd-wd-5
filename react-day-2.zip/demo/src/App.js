import logo from './logo.svg';
import './App.css';
import Header from './Header';
import Content from './Content';
import Footer from './Footer';
import { useState,useEffect } from "react";
import AddItem from './AddItem';
import SearchItem from './SearchItem';


function App() {
  function randomName() {
    const names = ["john", "peter"];
    const i = Math.floor(Math.random() * 2);
    return names[i];
  }
  const [items, setItems] = useState([
    { id: 1, checked: true, description: "Practice Coding" },
    { id: 2, checked: false, description: "Practice JS" },
    { id: 3, checked: true, description: "Practice Java" },
  ]);

  const handleCheck = (id) => {
    // console.log(id);
    const listItems = items.map((item) =>
      //   item.id === id
      //     ? { id: item.id, checked: !item.checked, description: item.description }
      //     : item
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    setItems(listItems);
  };

  const deleteTask = (id) => {
    // const listItems = items.map((item) => (item.id === id ? {} : item)); //// empty element will be present in the list
    const listItems = items.filter((item) => item.id !== id);
    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const addItem = (i) => { 
    const id = items.length ? items[items.length - 1].id + 1 : 1;
    const addNewItem = { id: id, checked: false, description: i };
    const listItems = [...items, addNewItem];
    console.log(listItems);
    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("submitted");
    console.log(newItem);
    if (!newItem) return;
    addItem(newItem);
    setNewItem(""); 
  };

  const [newItem, setNewItem] = useState();
  const [searchItem, setSearchItem] = useState("");
  // useEffect(() => setItems(JSON.parse(localStorage.getItem("todo_list"))), []);

  const API_URL = "http://localhost:3500/db"
  const [isError, setIsError] = useState(null)
  const [isLoading, setIsLoading] = useState(true)


  useEffect(()=>{
    const fetchItems = async()=>{
      try {
        const response = await fetch(API_URL)
        if(!response.ok) throw new Error("Data not found");
        const listItems = await response.json();
        console.log(listItems);
        setItems(listItems)
      } catch (error) {
          setIsError(error.message)
      }finally{
        setIsLoading(false);
      }
    }

    setTimeout(() => {
      (async()=> await fetchItems())()
    }, 2000);
  },[])

  return (
    <div className="App">
       <Header  />
       <AddItem 
        newItem={newItem}
        setNewItem={setNewItem}
        handleSubmit={handleSubmit}
      />
        <SearchItem
        searchItem={searchItem}
        setSearchItem={setSearchItem}
      />
      <main>
        {isError && <p>{isError}</p>}
        {isLoading && <p>Loading Items</p>}
      {!isError && !isLoading && (<Content
        items={items} 
        handleCheck={handleCheck}
        deleteTask={deleteTask}
      />)}
      </main>
       
      <Footer length={items.length} /> 
    </div>
  );
}

export default App;
