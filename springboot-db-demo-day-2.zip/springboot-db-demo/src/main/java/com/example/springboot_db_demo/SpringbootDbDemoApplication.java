package com.example.springboot_db_demo;

import com.example.springboot_db_demo.dto.UserDto;
import com.example.springboot_db_demo.entity.User;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringbootDbDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootDbDemoApplication.class, args);
    }

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();

//        modelMapper.createTypeMap(User.class, UserDto.class)
//                .addMapping(User::getEmail,UserDto::setEmail);

        return modelMapper;
    }
}
