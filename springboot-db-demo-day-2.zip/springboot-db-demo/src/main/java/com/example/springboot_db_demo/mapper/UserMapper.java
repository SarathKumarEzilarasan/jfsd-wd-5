package com.example.springboot_db_demo.mapper;

import com.example.springboot_db_demo.dto.UserDto;
import com.example.springboot_db_demo.entity.User;

public class UserMapper {

    // entity -> dto
    public static UserDto mapToUserDto(User user){
        UserDto userDto = new UserDto(
                user.getId(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail()
                );
        return userDto;
    }

    // dto -> entity
    public static User mapToUser(UserDto userDto){
        User user = new User(
                userDto.getId(),
                userDto.getFirstName(),
                userDto.getLastName(),
                userDto.getEmail()
        );
        return user;
    }
}
