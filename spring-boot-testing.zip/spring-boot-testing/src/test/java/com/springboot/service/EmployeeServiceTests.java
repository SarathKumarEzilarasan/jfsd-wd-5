package com.springboot.service;

import com.springboot.exception.ResourceNotFoundException;
import com.springboot.model.Employee;
import com.springboot.repository.EmployeeRepository;
import com.springboot.service.impl.EmployeeServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTests {
    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @Test
    public void givenEmployeeObject_whenSaveEmployee_thenReturnSavedEmployee() {
        //given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");

        given(employeeRepository.findByEmail(employee.getEmail()))
                .willReturn(Optional.empty());
        given(employeeRepository.save(employee)).willReturn(employee);
        //when
        Employee savedEmployee = employeeService.saveEmployee(employee);
        //then
        assertThat(savedEmployee).isNotNull();
    }

    @Test
    public void givenExistingEmail_whenSaveEmployee_thenThrowsException() {
        //given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");

        given(employeeRepository.findByEmail(employee.getEmail()))
                .willReturn(Optional.of(employee));
        //when
        assertThrows(ResourceNotFoundException.class, () -> employeeService.saveEmployee(employee));
        //then
        verify(employeeRepository, never()).save(any(Employee.class));
    }


    @Test
    public void givenEmployeeList_whenGetAllEmployees_thenReturnEmployeeList() {
        //given
        Employee john = new Employee();
        john.setFirstName("john");
        john.setLastName("doe");
        john.setEmail("john@gmail.com");

        Employee peter = new Employee();
        peter.setFirstName("peter");
        peter.setLastName("doe");
        peter.setEmail("peter@gmail.com");

        given(employeeRepository.findAll())
                .willReturn(List.of(john, peter));

        //when
        List<Employee> employees = employeeService.getAllEmployees();
        //then
        assertThat(employees).isNotNull();
        assertThat(employees.size()).isEqualTo(2);
    }

    @Test
    public void givenEmptyEmployeeList_whenGetAllEmployees_thenReturnEmptyEmployeeList() {
        //given
        given(employeeRepository.findAll())
                .willReturn(Collections.emptyList());

        //when
        List<Employee> employees = employeeService.getAllEmployees();
        //then
        assertThat(employees).isEmpty();
        assertThat(employees.size()).isEqualTo(0);
    }


    @Test
    public void givenEmployeeId_whenGetEmployeeById_thenReturnEmployeeObject() {
        //given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");

        given(employeeRepository.findById(employee.getId()))
                .willReturn(Optional.of(employee));
        //when
        Employee savedEmployee = employeeService.getEmployeeById(employee.getId()).get();
        //then
        assertThat(savedEmployee).isNotNull();
    }

    @Test
    public void givenEmployeeObject_whenUpdateEmployee_thenReturnUpdatedEmployee() {
        //given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");

        given(employeeRepository.save(employee))
                .willReturn(employee);

        //when
        Employee savedEmployee = employeeService.updateEmployee(employee);
        //then
        assertThat(savedEmployee).isNotNull();
    }

}
