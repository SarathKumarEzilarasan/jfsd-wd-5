package com.springboot.repository;

import com.springboot.model.Employee;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;


@DataJpaTest
public class EmployeeRepositoryTests {
    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    public void givenEmployeeObject_whenSave_thenReturnSavedEmployee() {
        //given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");

        //when
        Employee savedEmployee = employeeRepository.save(employee);

        //then
        assertThat(savedEmployee).isNotNull();
        assertThat(savedEmployee.getId()).isGreaterThan(0);
    }

    @Test
    public void givenEmployeeList_whenFindAll_thenReturnEmployeeList() {
        //given
        Employee john = new Employee();
        john.setFirstName("john");
        john.setLastName("doe");
        john.setEmail("john@gmail.com");

        Employee peter = new Employee();
        peter.setFirstName("peter");
        peter.setLastName("doe");
        peter.setEmail("peter@gmail.com");
        employeeRepository.save(john);
        employeeRepository.save(peter);

        //when
        List<Employee> employees = employeeRepository.findAll();

        //then
        assertThat(employees).isNotNull();
        assertThat(employees.size()).isEqualTo(2);
    }

    @Test
    public void givenEmployeeObject_whenFindById_thenReturnEmployeeObject() {
        //given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");
        Employee savedEmployee = employeeRepository.save(employee);

        //when
        Employee employeeDb = employeeRepository.findById(savedEmployee.getId()).get();

        //then
        assertThat(employeeDb).isNotNull();
    }

    @Test
    public void givenEmployeeEmail_whenFindByEmail_thenReturnEmployeeObject() {
        //given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");
        Employee savedEmployee = employeeRepository.save(employee);

        //when
        Employee employeeDb = employeeRepository.findByEmail(savedEmployee.getEmail()).get();

        //then
        assertThat(employeeDb).isNotNull();
    }

    @Test
    public void givenEmployeeObject_whenDelete_thenRemoveEmployee() {
        //given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");
        Employee savedEmployee = employeeRepository.save(employee);

        //when
        employeeRepository.deleteById(savedEmployee.getId());
        Optional<Employee> employeeDb = employeeRepository.findById(savedEmployee.getId());

        //then
        assertThat(employeeDb).isEmpty();
    }
}
