package com.example.spring_security_demo.exception;

import java.time.LocalDateTime;

public class ErrorDetails {
    private LocalDateTime time;
    private String message;
    private String path;
    private String statusCode;

    public ErrorDetails() {
    }

    public ErrorDetails(LocalDateTime time, String message, String path, String statusCode) {
        this.time = time;
        this.message = message;
        this.path = path;
        this.statusCode = statusCode;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}
