//package demo;
//
//public sealed class Test permits Child1 {
//}
//
//
//sealed class Child1 extends Test permits GrandChild {
//
//}
//
//class Child2 extends Test {
//
//}
//
//class GrandChild extends Child1 {
//
//}