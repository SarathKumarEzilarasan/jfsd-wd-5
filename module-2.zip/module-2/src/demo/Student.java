package demo;

public class Student implements Comparable<Student> {

    private String name;
    private Integer grade;
    private String department;

    public Student(String name, int grade, String department) {
        this.name = name;
        this.grade = grade;
        this.department = department;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(int age) {
        this.grade = age;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public int compareTo(Student o) {
        return this.getGrade().compareTo(o.getGrade());
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", grade=" + grade +
                ", department='" + department + '\'' +
                '}';
    }
}
