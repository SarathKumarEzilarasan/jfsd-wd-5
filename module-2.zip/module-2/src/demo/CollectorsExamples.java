package demo;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectorsExamples {
    public static void main(String[] args) {
        doAvgInt();
    }

    public static void doPartitioning1() {
        Map<Boolean, List<String>> map = Stream.of("john", " doe", " from", " java")
                .collect(
//                        Collectors.partitioningBy(s -> s.startsWith("j"))
                        Collectors.partitioningBy(s -> s.length() > 2)
                );

        System.out.println(map);
    }

    public static void doPartitioning2() {
        Map<Boolean, Set<String>> map = Stream.of("john", " doe", " from", "john")
                .collect(
                        Collectors.partitioningBy(
                                s -> s.length() > 2,
                                Collectors.toSet()
                        )
                );

        System.out.println(map);
    }

    public static void doGroupingBy1() {
        Map<Integer, List<String>> map = Stream.of("john", "doe", "from", "john")
                .collect(
                        Collectors.groupingBy(s -> s.length())
                );

        System.out.println(map);
    }

    public static void doGroupingBy2() {
        Map<Integer, Set<String>> map = Stream.of("john", "doe", "from", "john")
                .collect(
                        Collectors.groupingBy(
                                String::length,
                                Collectors.toSet()
                        )
                );

        System.out.println(map);
    }

    public static void doGroupingBy3() {
        Map<Integer, Set<String>> map = Stream.of("john", "doe", "from", "john", "adam")
                .collect(
                        Collectors.groupingBy(
                                String::length,
                                TreeMap::new,
                                Collectors.toSet()
                        )
                );

        System.out.println(map);
    }

    public static void doCollectToMap1() {
        Map<String, Integer> map = Stream.of("john", "doe", "from", "adam")
                .collect(
                        Collectors.toMap(
                                String::toUpperCase,
                                String::length
                        )
                );

        System.out.println(map);
    }

    public static void doCollectToMap2() {
        Map<String, Integer> map = Stream.of("john", "doe", "from", "adam", "john")
                .collect(
                        Collectors.toMap(
                                String::toUpperCase,
                                String::length,
                                (s1, s2) -> s1 + s2
                        )
                );

        System.out.println(map);
    }

    public static void doCollectToMap3() {
        Map<String, Integer> map = Stream.of("john", "doe", "from", "adam", "john")
                .collect(
                        Collectors.toMap(
                                String::toUpperCase,
                                String::length,
                                (s1, s2) -> s1 + s2,
                                TreeMap::new
                        )
                );

        System.out.println(map);
    }

    public static void doJoining() {
        String result = Stream.of("john", "doe", "from", "adam", "john")
                .collect(
                        Collectors.joining(",")
                );

        System.out.println(result);
    }

    public static void doAvgInt() {
        double result = Stream.of("john", "doe", "from", "adam", "john")
                .collect(
                        Collectors.averagingInt(String::length)
                );

        System.out.println(result);
    }


}
