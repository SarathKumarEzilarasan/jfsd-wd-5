package demo;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectorsExamples {
    public static void main(String[] args) {
        doGroupingBy1();
    }

    public static void doPartitioning1() {
        Map<Boolean, List<String>> map = Stream.of("john", " doe", " from", " java")
                .collect(
//                        Collectors.partitioningBy(s -> s.startsWith("j"))
                        Collectors.partitioningBy(s -> s.length() > 2)
                );

        System.out.println(map);
    }

    public static void doPartitioning2() {
        Map<Boolean, Set<String>> map = Stream.of("john", " doe", " from", "john")
                .collect(
                        Collectors.partitioningBy(
                                s -> s.length() > 2,
                                Collectors.toSet()
                        )
                );

        System.out.println(map);
    }

    public static void doGroupingBy1() {
        Map<Integer, List<String>> map = Stream.of("john", "doe", "from", "john")
                .collect(
                        Collectors.groupingBy(s -> s.length())
                );

        System.out.println(map);
    }
}
