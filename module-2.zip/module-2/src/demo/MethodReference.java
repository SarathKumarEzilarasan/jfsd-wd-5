package demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class MethodReference {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("John","Peter");

        names.forEach(name -> System.out.println(name));
        names.forEach(System.out::println);
    }

    private static void boundedMethodReference() {
        String name = "John doe";
        Supplier<String> lowerName = () -> name.toLowerCase();
        Supplier<String> lowerNameMR = name::toLowerCase;
        System.out.println(lowerNameMR.get());

        Predicate<String> titleLower = title -> name.startsWith(title);
        Predicate<String> titleLowerMR = name::startsWith;

        System.out.println(titleLowerMR.test("John"));
    }

    public static void unboundMethodReference(){
        Function<String,String> upperL = s -> s.toUpperCase();
        Function<String,String> upperMR = String::toUpperCase;
        System.out.println(upperMR.apply("john"));
    }

    public static void constructorMethodReference(){
        Supplier<StringBuilder> sbL = () -> new StringBuilder();
        Supplier<StringBuilder> sbMR = StringBuilder::new;

        Function<Integer, List<String>> alL = x -> new ArrayList<>(x);
        Function<Integer, List<String>> alMR = ArrayList::new;
    }
}
