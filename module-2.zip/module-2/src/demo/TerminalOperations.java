package demo;

import java.util.Optional;
import java.util.stream.Stream;

public class TerminalOperations {
    public static void main(String[] args) {
        doReduce3();
    }

    public static void doReduce1() {
        Optional<String> name = Stream.of("john", "doe", " from", " java")
                .filter(s -> s.length() > 30)
                .reduce((s, c) -> s + c);

        name.ifPresent(System.out::println);
    }

    public static void doReduce2() {
        String name = Stream.of("john", "doe", " from", " java")
                .filter(s -> s.length() > 3)
                .reduce("default value", (s, c) -> s + c);

        System.out.println(name);
    }

    public static void doReduce3() {
        int length = Stream.of("john", "doe", " from", " java")
                .reduce(
                        0,
                        (n, str) -> n + str.length(),
                        (n1, n2) -> n1 + n2
                );

        System.out.println(length);
    }

    public static void doForEach() {
        Stream.of("john", " doe", " from", " java")
                .forEach(System.out::println);
//        Stream<String> stream = Stream.of("john", " doe", " from", " java");
//
//        for (String s:stream){
//
//        }
    }

    public static void doMatches() {
        boolean anyMatch = Stream.of("john", " doe", " from", " java")
                .anyMatch(name -> name.startsWith("j")); // ????
        System.out.println(anyMatch);
        boolean allMatch = Stream.of("john", "java")
                .allMatch(name -> name.startsWith("j")); // ????
        System.out.println(allMatch);
        boolean noneMatch = Stream.of(" doe", " from")
                .noneMatch(name -> name.startsWith("j")); // ????
        System.out.println(noneMatch);
    }

    public static void doFindAnyFindFirst() {
        Optional<String> any = Stream.of("john", " doe", " from", " java")
                .findAny();
        any.ifPresent(System.out::println);

        Optional<String> first = Stream.of("john", " doe", " from", " java")
                .findFirst();
        first.ifPresent(System.out::println);
    }


    public static void doCount() {
        long count = Stream.of("john", " doe", " from", " java").count();
        System.out.println(count);
    }

    public static void doMinAndMax() {
        Optional<Object> min = Stream.empty()
                .min((o1, o2) -> ((String) o1).length() - ((String) o2).length());
        min.ifPresent(System.out::println);
    }


    public static void doCollect() {
        StringBuilder stringBuilder = Stream.of("john", " doe", " from", " java")
                .collect(StringBuilder::new, StringBuilder::append, StringBuilder::append);
        System.out.println(stringBuilder);
    }
}
