package demo;


import java.util.stream.Stream;

public class Demo {
    public static void main(String[] args) {
        Stream.of(10, 20, 30, 40, 50, 60)
                .parallel()
                .forEach(System.out::println);

    }
}
