package demo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class IntermediateOperations {
    public static void main(String[] args) {
        doSort();
    }

    //filter , map

    public static void doSort() {
        Stream.of("john", "doe", "from", "john", "a")
                .sorted((a, b) -> a.length() - b.length())
                .forEach(System.out::println);

        Stream.of("john", "doe", "from", "john", "a")
                .sorted(Comparator.comparing(a -> a.length()))
                .forEach(System.out::println);
    }

    public static void doFlatMap() {
        List<String> list1 = Arrays.asList("john", "doe");
        List<String> list2 = Arrays.asList("peter", "doe");

        Stream<List<String>> listStream = Stream.of(list1, list2);

        listStream.flatMap(list -> list.stream())
                .forEach(System.out::println);

    }

    public static void doDistinct() {
        Stream.of("john", "doe", " from", "john")
                .peek(s -> System.out.println("1." + s))
                .distinct()
                .forEach(s -> System.out.println("2." + s));
    }

    public static void doLimit() {
        Stream.of("john", "doe", " from", "john")
                .limit(2)
                .forEach(System.out::println);
    }


}

class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}