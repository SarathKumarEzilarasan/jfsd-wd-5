package demo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class DateExamples {

    public static void main(String[] args) {
        _Employee employee = new _Employee(1, "A", 2000);
        _Employee employee1 = new _Employee(1, "A", 2000);
        System.out.println(employee.equals(employee1));
        System.out.println(employee.hashCode());
        System.out.println(employee1.hashCode());

        System.out.println(employee.name());
    }

    public static void teeing() {
        // teeing
        List<Employee> employees = Arrays.asList(
                new Employee(1, "A", 2000),
                new Employee(2, "B", 3000),
                new Employee(3, "C", 4000)
        );
        System.out.println(employees.stream().filter(e -> e.getSalary() > 2000).collect(Collectors.toList()));
        System.out.println(employees.stream()
                .collect(Collectors.filtering(e -> e.getSalary() > 2000, Collectors.toList())));

        HashMap<String, Employee> result = employees.stream().
                collect(
                        Collectors.teeing(
                                Collectors.maxBy((a, b) -> a.getSalary().compareTo(b.getSalary())),
                                Collectors.minBy((a, b) -> a.getSalary().compareTo(b.getSalary())),
                                (e1, e2) -> {
                                    HashMap<String, Employee> map = new HashMap<>();
                                    map.put("Max", e1.get());
                                    map.put("Min", e2.get());
                                    return map;
                                }
                        )

                );

        System.out.println(result);

    }
}

class Employee {
    private long id;
    private String name;
    private Double salary;

    public Employee(long id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", salary=" + salary +
                '}';
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Double getSalary() {
        return salary;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Employee employee = (Employee) o;
        return id == employee.id && Objects.equals(name, employee.name) && Objects.equals(salary, employee.salary);
    }

    @Override
    public int hashCode() {
        int result = Long.hashCode(id);
        result = 31 * result + Objects.hashCode(name);
        result = 31 * result + Objects.hashCode(salary);
        return result;
    }
}