package demo;

import java.util.Optional;

public class OptionalExample {

    public static void main(String[] args) {
        withOptional();
    }

    public static void withoutOptional() {
        String value = getValue();
        if (value != null)
            System.out.println(value.toUpperCase());
    }

    public static String getValue() {
        return null;
    }

    public static void withOptional() {
        Optional<String> optional = getValueWithOptional();
        System.out.println(optional.isPresent());
    }

    public static Optional<String> getValueWithOptional() {
        return Optional.ofNullable(null);
    }
}
