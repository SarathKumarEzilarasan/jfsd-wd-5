package demo;

public record _Employee(long id, String name, double salary) {
    public static String print() {
        return "hello world";
    }
}
