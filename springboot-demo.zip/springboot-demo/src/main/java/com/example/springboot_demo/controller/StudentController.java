package com.example.springboot_demo.controller;

import com.example.springboot_demo.bean.Student;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("api")
public class StudentController {

    @GetMapping("student")
    public ResponseEntity<Student> getStudent() {
        Student student = new Student(1, "john", "doe");
        return ResponseEntity.ok(student);
    }

    @GetMapping("students")
    public ResponseEntity<List<Student>> getStudents() {
        Student student1 = new Student(1, "john", "doe");
        Student student2 = new Student(2, "peter", "doe");
        List<Student> students = Arrays.asList(student1, student2);
        return ResponseEntity.ok(students);
    }

    @GetMapping("query")
    public ResponseEntity<Student> getStudentById(@RequestParam int id) {
        Student student = new Student(1, "john", "doe");
        System.out.println(id);
        return ResponseEntity.ok(student);
    }

    @GetMapping("path/{id}")
    public ResponseEntity<Student> getStudentByPathParam(@PathVariable("id") int studentId) {
        Student student = new Student(1, "john", "doe");
        System.out.println(studentId);
        return ResponseEntity.ok(student);
    }

    @PostMapping("student")
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        Student student1 = new Student(1, student.getFirstName(), student.getLastName());
        System.out.println(1 / 0);
        return new ResponseEntity<>(student1, HttpStatus.CREATED);
    }

    @PutMapping("student/{id}")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student
            , @PathVariable("id") int id) {
        Student student1 = new Student(id, student.getFirstName(), student.getLastName());
        return new ResponseEntity<>(student1, HttpStatus.OK);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int id){
        return new ResponseEntity<>("Student deleted successfully", HttpStatus.NO_CONTENT);
    }
}
