create table people (
    person_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    first_name varchar(20),
    last_name varchar(20)
);