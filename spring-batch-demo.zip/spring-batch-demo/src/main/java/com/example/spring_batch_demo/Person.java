package com.example.spring_batch_demo;

public record Person(String firstName, String lastName) {
}
