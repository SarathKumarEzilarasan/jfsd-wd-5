package com.example.spring_batch_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
