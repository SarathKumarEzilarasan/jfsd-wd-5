package com.example.springboot_db_demo;

import com.example.springboot_db_demo.dto.UserDto;
import com.example.springboot_db_demo.entity.User;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@OpenAPIDefinition(
        info = @Info(
                title = "Spring Boot REST API Documentation",
                description = "User Management System",
                version = "v1.0",
                contact = @Contact(
                        name = "John",
                        email = "test@gmail.com",
                        url = "https://www.google.com"
                )
        )
)
public class SpringbootDbDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootDbDemoApplication.class, args);
    }

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();

//        modelMapper.createTypeMap(User.class, UserDto.class)
//                .addMapping(User::getEmail,UserDto::setEmail);

        return modelMapper;
    }
}
