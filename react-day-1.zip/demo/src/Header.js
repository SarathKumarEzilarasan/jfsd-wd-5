import React from 'react'

const Header = () => {
  const headerStyle = {backgroundColor: "blue"};
  return (
    <header style={headerStyle}>To do list</header>
  )
}

export default Header