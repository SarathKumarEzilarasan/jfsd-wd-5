import React from 'react'
import { useState } from 'react'
import {FaTrash} from "react-icons/fa"

const Content = () => {

    const [count,setCount] = useState(99)
    const [name,setName] = useState("john")


    function randomName(){
        const names = ["john","peter"];
        const i = Math.floor(Math.random()*2);
        return setName(names[i])
    }

    // const addItem = () =>{
    //     console.log("Item Added");
    // }

    // const addItem = (name) =>{
    //     console.log(name);
    // }

    const addItem = (e) =>{
        console.log(e.target.innerText);
    }

    // if(true) useState();

    function decrementFunc(){
        setCount((count)=> --count)
    }

    function incrementFunc(){
        // setCount(count+1)
        // setCount(count+1)
        // setCount(count+1)

        setCount((count)=> ++count)
        setCount((count)=> ++count)
        setCount((count)=> ++count)
    }


  return (
    <main>
         <p>Logged in by {name}</p>
         {/* <button onClick={addItem}>Add</button> */}
         {/* <button onClick={addItem("John")}>Add</button> */}
         {/* <button onClick={()=> addItem("John")}>Add</button> */}
         {/* <button onClick={(e)=> addItem(e)}>Add</button> */}

         <button onClick={decrementFunc}>-</button>
         <span>{count}</span>
         <button onClick={incrementFunc}>+</button>
         <button onClick={randomName}>Change</button>

       
            
    </main>
    
  )
}

export default Content