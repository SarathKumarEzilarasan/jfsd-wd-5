import React from 'react'
import { useState } from 'react'


const Content = () => {

const [items, setItems] = useState(
    [
        {id:1 , checked: true , description: "Practise HTML"},
        {id:2 , checked: false , description: "Practise CSS"},
        {id:3 , checked: true , description: "Practise JS"},
    ]
)

    const handleCheck = (id)=>{
      const listItems = items.map((item)=> item.id === id ? {...item, checked: !item.checked }: item);
      setItems(listItems);
    }

    const deleteTask = (id)=>{
        const listItems =  items.filter((item)=> item.id !== id);
        setItems(listItems);
    }

  return (
    <main>
       <ul>
         {items.map((item)=>(
            <li className='item' key={item.id}>
                <input type="checkbox" checked ={item.checked} onChange={()=> handleCheck(item.id)} ></input>
                <label style={item.checked ? {textDecoration: "line-through"}: null}>{item.description}</label>
                <button onClick={()=> deleteTask(item.id)}>Delete</button>
            </li>
         ))}
       </ul>    
    </main>
    
  )
}

export default Content