package com.example.springboot_db_demo.service;

import com.example.springboot_db_demo.entity.User;

public interface UserService {
    User createUser(User user);
}
