package com.example.springboot_db_demo.service.impl;

import com.example.springboot_db_demo.entity.User;
import com.example.springboot_db_demo.repository.UserRepository;
import com.example.springboot_db_demo.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
//@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }
}
