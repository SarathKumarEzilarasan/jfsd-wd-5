package com.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/sq")
public class SqServlet extends HttpServlet {

    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

//        int sum = Integer.parseInt(req.getParameter("sum"));

        HttpSession session = req.getSession();
        int sum = (int) session.getAttribute("sum");

        resp.getWriter().println(sum * sum);


//        List<Cookie> cookies = Arrays.stream(req.getCookies())
//                .filter(cookie -> cookie.getName().equals("sum")).toList();
//        cookies.get(0);


    }

}
