package com.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/add")
public class AddServlet extends HttpServlet {

    public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

            req.setAttribute("name","john");
            req.getRequestDispatcher("display.jsp").forward(req,res);

//        int i = Integer.parseInt(req.getParameter("num1"));
//        int j = Integer.parseInt(req.getParameter("num2"));
//        int sum = i + j;
//        System.out.println();
//        PrintWriter writer = res.getWriter();
//
//
////        req.setAttribute("sum", sum);
////        RequestDispatcher requestDispatcher = req.getRequestDispatcher("sq");
////        requestDispatcher.forward(req, res);
//
////        res.sendRedirect("sq?sum=" + sum);
//
//        ServletContext servletContext = getServletContext();
//        String email = servletContext.getInitParameter("email");
//
//        HttpSession session = req.getSession();
//        session.setAttribute("sum", sum);
//        res.sendRedirect("sq");
//
//
////        Cookie cookie = new Cookie("sum", sum + "");
////        res.addCookie(cookie);

    }
}
