package com.example.spring_security_demo.service.impl;

import com.example.spring_security_demo.dto.ToDoDto;
import com.example.spring_security_demo.entity.ToDo;
import com.example.spring_security_demo.exception.ResourceNotFoundException;
import com.example.spring_security_demo.repository.ToDoRepository;
import com.example.spring_security_demo.service.ToDoService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ToDoServiceImpl implements ToDoService {
    private ToDoRepository toDoRepository;
    private ModelMapper modelMapper;

    public ToDoServiceImpl(ToDoRepository toDoRepository, ModelMapper modelMapper) {
        this.toDoRepository = toDoRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public ToDoDto addToDo(ToDoDto toDoDto) {
        ToDo toDo = modelMapper.map(toDoDto, ToDo.class);
        ToDo savedToDo = toDoRepository.save(toDo);

        return modelMapper.map(savedToDo, ToDoDto.class);
    }

    @Override
    public ToDoDto getToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));

        return modelMapper.map(toDo, ToDoDto.class);
    }

    @Override
    public List<ToDoDto> getAllTodos() {
        List<ToDo> toDoList = toDoRepository.findAll();
        return toDoList.stream()
                .map(toDo -> modelMapper.map(toDo, ToDoDto.class)).toList();
    }

    @Override
    public ToDoDto updateToDo(ToDoDto toDoDto, Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));

        toDo.setTitle(toDoDto.getTitle());
        toDo.setDescription(toDoDto.getDescription());
        toDo.setCompleted(toDoDto.getCompleted());

        ToDo updatedTodo = toDoRepository.save(toDo);
        return modelMapper.map(updatedTodo, ToDoDto.class);
    }

    @Override
    public void deleteToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));
        toDoRepository.delete(toDo);
    }

    @Override
    public ToDoDto completeToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));
        toDo.setCompleted(true);

        ToDo updatedTodo = toDoRepository.save(toDo);
        return modelMapper.map(updatedTodo, ToDoDto.class);
    }

    @Override
    public ToDoDto incompleteToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));
        toDo.setCompleted(false);

        ToDo updatedTodo = toDoRepository.save(toDo);
        return modelMapper.map(updatedTodo, ToDoDto.class);
    }
}
