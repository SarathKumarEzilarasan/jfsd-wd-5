let form = document.getElementById("addForm");
let items = document.getElementById("items");
let filter = document.getElementById("filter");


form.addEventListener('submit',(e)=>{
    e.preventDefault()
    
    // <li class="list-group-item">Item 1 <button class="btn btn-danger btn-sm float-right delete">X</button></li>

    let newItem = document.getElementById("item").value;

    let li = document.createElement('li');
    li.className = "list-group-item";
    li.appendChild(document.createTextNode(newItem))


    let deleteBtn = document.createElement('button')
    deleteBtn.className = "btn btn-danger btn-sm float-right delete";

    deleteBtn.appendChild(document.createTextNode("X"))

    li.appendChild(deleteBtn)

    items.appendChild(li)

})

items.addEventListener('click',(e)=>{
    if(e.target.classList.contains('delete')){
        if(confirm('Are you sure?')){
            let li = e.target.parentElement;
            items.removeChild(li)
        }
    }
})

filter.addEventListener('keyup',(e)=>{
   let text = e.target.value.toLowerCase();
   let itemsList = items.getElementsByTagName("li")


    Array.from(itemsList).forEach(item => {
       let itemText = item.firstChild.textContent.toLowerCase();
       
       if(!itemText.includes(text)){
            item.style.display = 'none'
       }else{
            item.style.display = 'block'
       }

    })

})