package com.example.jfsd_mvc_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JfsdMvcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
