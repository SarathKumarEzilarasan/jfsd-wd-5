package com.example.jfsd_mvc_demo.controller;

import com.example.jfsd_mvc_demo.model.User;
import com.example.jfsd_mvc_demo.model.UserForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class UserController {

    @GetMapping("variable")
    public String variableExpression(Model model) {
        User user = new User("admin", "admin@gmail.com", "ADMIN", "Male");
        model.addAttribute("user", user);
        return "variable-expression";
    }

    @GetMapping("selection")
    public String selectionExpression(Model model) {
        User user = new User("admin", "admin@gmail.com", "ADMIN", "Male");
        model.addAttribute("user", user);
        return "selection-expression";
    }

    @GetMapping("message")
    public String messageExpression() {
        return "message-expression";
    }

    @GetMapping("link")
    public String linkExpression(Model model) {
        model.addAttribute("id", 1);
        return "link-expression";
    }

    @GetMapping("fragment")
    public String fragmentExpression() {
        return "fragment-expression";
    }

    @GetMapping("/users")
    public String users(Model model) {
        User admin = new User("Admin", "admin@gmail.com", "ADMIN", "male");
        User john = new User("john", "john@gmail.com", "USER", "male");
        User peter = new User("peter", "peter@gmail.com", "USER", "male");
        List<User> users = Arrays.asList(admin, john, peter);

        model.addAttribute("users", users);
        return "users";
    }

    @GetMapping("/if-unless")
    public String ifUnless(Model model) {
        User admin = new User("Admin", "admin@gmail.com", "ADMIN", "male");
        User john = new User("john", "john@gmail.com", "USER", "male");
        User peter = new User("peter", "peter@gmail.com", "USER", "male");
        List<User> users = Arrays.asList(admin, john, peter);

        model.addAttribute("users", users);
        return "if-unless";
    }

    @GetMapping("/switch-case")
    public String switchCase(Model model) {
        User admin = new User("Admin", "admin@gmail.com", "ADMIN", "male");
        User john = new User("john", "john@gmail.com", "USER", "male");
        User peter = new User("peter", "peter@gmail.com", "USER", "male");
        List<User> users = Arrays.asList(admin, john, peter);

        model.addAttribute("users", users);
        return "switch-case";
    }

    @GetMapping("register")
    public String userRegistrationPage(Model model) {
        UserForm userForm = new UserForm();
        model.addAttribute("userForm", userForm);

        List<String> professions = Arrays.asList("developer", "tester", "HR");
        model.addAttribute("professions", professions);
        return "register-form";
    }

    @PostMapping("/register/save")
    public String submitForm(Model model, @ModelAttribute("userForm") UserForm userForm) {
        model.addAttribute("userForm", userForm);
        return "register-success";
    }
}
