package com.example.spring_security_demo.controller;

import com.example.spring_security_demo.dto.ToDoDto;
import com.example.spring_security_demo.service.ToDoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/todos")
public class ToDoController {
    private ToDoService toDoService;

    public ToDoController(ToDoService toDoService) {
        this.toDoService = toDoService;
    }

//    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<ToDoDto> addToDo(@RequestBody ToDoDto toDoDto) {
        ToDoDto savedTodoDto = toDoService.addToDo(toDoDto);
        return new ResponseEntity<>(savedTodoDto, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<ToDoDto> getToDo(@PathVariable("id") Long toDoDtoId) {
        ToDoDto toDoDto = toDoService.getToDo(toDoDtoId);
        return new ResponseEntity<>(toDoDto, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<ToDoDto>> getAllToDos() {
        List<ToDoDto> toDoDtos = toDoService.getAllTodos();
        return new ResponseEntity<>(toDoDtos, HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<ToDoDto> updatedToDo(@RequestBody ToDoDto toDoDto, @PathVariable("id") Long toDoDtoId) {
        ToDoDto updateToDo = toDoService.updateToDo(toDoDto, toDoDtoId);
        return new ResponseEntity<>(updateToDo, HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteTodo(@PathVariable("id") Long toDoDtoId) {
        toDoService.deleteToDo(toDoDtoId);
        return new ResponseEntity<>("Todo deleted successfully", HttpStatus.OK);
    }

    @PatchMapping("{id}/complete")
    public ResponseEntity<ToDoDto> completeToDo(@PathVariable("id") Long toDoDtoId) {
        ToDoDto updateToDo = toDoService.completeToDo(toDoDtoId);
        return new ResponseEntity<>(updateToDo, HttpStatus.OK);
    }

    @PatchMapping("{id}/incomplete")
    public ResponseEntity<ToDoDto> incompleteToDo(@PathVariable("id") Long toDoDtoId) {
        ToDoDto updateToDo = toDoService.incompleteToDo(toDoDtoId);
        return new ResponseEntity<>(updateToDo, HttpStatus.OK);
    }


}
